
interface IEvent {
	
	//method to be implemented in each event to return total points earned
	double pointsEarned();
}
