
class ShootingRound {
	int targetsHit;
	//Takes the targets hit per single round
	ShootingRound(int targetsHit) {
		this.targetsHit = targetsHit;
	}
}
